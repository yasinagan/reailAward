package com.customer.retail.constant;

public class Constant {
    public static final int DAYS_IN_MONTHS = 30;
    public static int first_Reward_Limit = 50;
    public static int second_Reward_Limit = 100;
}
