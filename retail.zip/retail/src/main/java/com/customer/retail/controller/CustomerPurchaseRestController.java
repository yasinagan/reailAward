package com.customer.retail.controller;

import com.customer.retail.services.CustomerPurchaseService;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/customer")
public class CustomerPurchaseRestController
{
    final CustomerPurchaseService purchaseService;

    public CustomerPurchaseRestController(CustomerPurchaseService purchaseService)
    {
        this.purchaseService = purchaseService;
    }

    @GetMapping(value = "/reward/{customerId}")
    public ResponseEntity getRewardByCustomerId( @PathVariable int customerId)
    {
        return purchaseService.getRewardByCustomerId(customerId);

    }
}
