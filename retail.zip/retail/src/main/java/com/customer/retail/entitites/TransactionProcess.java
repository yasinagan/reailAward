package com.customer.retail.entitites;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import java.sql.Timestamp;

@Entity
@Data
public class TransactionProcess
{
    @Id
    @GeneratedValue( strategy = GenerationType.IDENTITY)
    private Integer transactionId;

    private Integer customerId;

    private Timestamp transactionDate;

    private double transactionAmount;

}
