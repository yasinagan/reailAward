package com.customer.retail.repository;

import com.customer.retail.entitites.Customer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

public interface CustomerRepository extends JpaRepository<Customer, Integer>
{
    Optional<Customer> findByCustomerIdEquals(Integer customerId);
}