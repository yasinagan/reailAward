package com.customer.retail.repository;

import com.customer.retail.entitites.TransactionProcess;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.sql.Timestamp;
import java.util.List;
import java.util.Optional;

public interface TransactionPorcessRepository extends JpaRepository<TransactionProcess, Integer>
{
    public List<TransactionProcess> findAllByCustomerIdAndTransactionDateBetween(Integer customerId, Timestamp from, Timestamp to);


}