package com.customer.retail.services;

import com.customer.retail.constant.Constant;
import com.customer.retail.entitites.Customer;
import com.customer.retail.entitites.TransactionProcess;
import com.customer.retail.model.Rewards;
import com.customer.retail.repository.CustomerRepository;
import com.customer.retail.repository.TransactionPorcessRepository;
import com.customer.retail.utilities.ERest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.time.Instant;
import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class CustomerPurchaseService
{

    final TransactionPorcessRepository transactionPorcessRepository;
    final CustomerRepository customerRepository;

    public CustomerPurchaseService(TransactionPorcessRepository transactionPorcessRepository, CustomerRepository customerRepository)
    {
        this.transactionPorcessRepository = transactionPorcessRepository;
        this.customerRepository = customerRepository;
    }

    public ResponseEntity getRewardByCustomerId(Integer customerId)
    {
        Map<ERest, Object> hm = new LinkedHashMap<>();
        try
        {
            Optional<Customer> customer = customerRepository.findByCustomerIdEquals(customerId);
            if (!customer.isPresent())
            {
                hm.put(ERest.status, false);
                hm.put(ERest.result, "missing customer_Id");
                return new ResponseEntity(hm, HttpStatus.NOT_FOUND);
            }
            else
            {
                Timestamp lastMonthTimestamp = getDateBasedOnOffSetDays(Constant.DAYS_IN_MONTHS);
                Timestamp lastSecondMonthTimestamp = getDateBasedOnOffSetDays(2 * Constant.DAYS_IN_MONTHS);
                Timestamp lastThirdMonthTimestamp = getDateBasedOnOffSetDays(3 * Constant.DAYS_IN_MONTHS);

                Customer customer1 = customer.get();

                List<TransactionProcess> lastMonthTransactions = transactionPorcessRepository.findAllByCustomerIdAndTransactionDateBetween
                        (customer1.getCustomerId(), lastMonthTimestamp, Timestamp.from(Instant.now()));

                List<TransactionProcess> lastSecondMonthTransactions = transactionPorcessRepository.findAllByCustomerIdAndTransactionDateBetween(
                        customerId, lastSecondMonthTimestamp, lastMonthTimestamp);

                List<TransactionProcess> lastThirdMonthTransactions = transactionPorcessRepository.findAllByCustomerIdAndTransactionDateBetween
                        (customerId, lastThirdMonthTimestamp, lastSecondMonthTimestamp);

                Long lastMonthRewardPoints = getRewardsPerMonth(lastMonthTransactions);
                Long lastSecondMonthRewardPoints = getRewardsPerMonth(lastSecondMonthTransactions);
                Long lastThirdMonthRewardPoints = getRewardsPerMonth(lastThirdMonthTransactions);

                Rewards rewards = new Rewards();
                rewards.setCustomerId(customer1.getCustomerId());
                rewards.setLastMonthRewardPoints(lastMonthRewardPoints);
                rewards.setLastSecondMonthRewardPoints(lastSecondMonthRewardPoints);
                rewards.setLastThirdMonthRewardPoints(lastThirdMonthRewardPoints);
                rewards.setTotalRewards(lastMonthRewardPoints + lastSecondMonthRewardPoints + lastThirdMonthRewardPoints);
                hm.put(ERest.status, true);
                hm.put(ERest.result, rewards);
                return new ResponseEntity(hm, HttpStatus.OK);
            }

        }
        catch (Exception e)
        {

            String message = e.getMessage();

            hm.put(ERest.status, false);
            hm.put(ERest.result, message);
            return new ResponseEntity(hm, HttpStatus.INTERNAL_SERVER_ERROR);

        }

    }

    private Long calculateRewards(TransactionProcess t)
    {
        if (t.getTransactionAmount() > Constant.first_Reward_Limit && t.getTransactionAmount() <= Constant.second_Reward_Limit)
        {
            return Math.round(t.getTransactionAmount() - Constant.first_Reward_Limit);
        }
        else if (t.getTransactionAmount() > Constant.second_Reward_Limit)
        {
            return Math.round(t.getTransactionAmount() - Constant.second_Reward_Limit) * 2
                    + (Constant.second_Reward_Limit - Constant.first_Reward_Limit);
        }
        else
            return 0l;

    }

    public Timestamp getDateBasedOnOffSetDays(int days)
    {
        return Timestamp.valueOf(LocalDateTime.now().minusDays(days));
    }

    private Long getRewardsPerMonth(List<TransactionProcess> transactions)
    {
        return transactions.stream().map(transaction -> calculateRewards(transaction))
                .collect(Collectors.summingLong(r -> r.longValue()));
    }
}
