package com.customer.retail.utilities;

public enum ERest
{
    status, result,message, error;
}
